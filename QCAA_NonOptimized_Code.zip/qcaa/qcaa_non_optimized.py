
import numpy as np
from qiskit import QuantumCircuit, Aer, execute
import matplotlib.pyplot as plt

def qcaa_non_optimized(x, shots=1024):
    if len(x) != 16:
        raise ValueError("Input vector must have 16 features.")

    # Step 1: Normalize input (already assumed normalized between 0 and 1)
    x_norm = np.clip(x, 0, 1)

    # Step 2–5: Quantum state preparation using Ry rotations
    circuit = QuantumCircuit(16, 16)
    for i in range(16):
        theta = 2 * np.arcsin(np.sqrt(x_norm[i]))
        circuit.ry(theta, i)

    # Step 6–8: Apply CNOT entanglement
    for i in range(15):
        circuit.cx(i, i + 1)

    # Step 9: Measurement
    circuit.measure(range(16), range(16))

    # Step 10: Execute circuit on simulator
    simulator = Aer.get_backend('qasm_simulator')
    job = execute(circuit, simulator, shots=shots)
    result = job.result()
    counts = result.get_counts()

    # Step 11: Calculate measurement probabilities
    probs = np.zeros(16)
    for outcome, count in counts.items():
        for i, bit in enumerate(reversed(outcome)):
            if bit == '1':
                probs[i] += count
    probs /= shots

    # Step 12: Reconstruct input
    x_reconstructed = np.arcsin(np.sqrt(probs))

    print("Original Input:", x_norm)
    print("Reconstructed:", x_reconstructed)
    print("Probabilities:", probs)

    # Optional: Visualize
    circuit.draw(output='mpl')
    plt.show()

    return x_reconstructed

# Example usage with dummy input
if __name__ == "__main__":
    dummy_input = np.random.rand(16)
    dummy_input /= np.max(dummy_input)  # Normalize between 0 and 1
    qcaa_non_optimized(dummy_input)
