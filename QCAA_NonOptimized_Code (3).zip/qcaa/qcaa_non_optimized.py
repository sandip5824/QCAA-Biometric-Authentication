"""
Quantum-Classical Adaptive Autoencoder (QCAA) - Non-Optimized Version

This script simulates a hybrid quantum-classical autoencoding procedure using
parameterized quantum circuits with angle encoding and linear entanglement.

Author: [Your Name]
"""

import numpy as np
from qiskit import QuantumCircuit, Aer, transpile, assemble
from qiskit.visualization import plot_bloch_vector

def normalize_input(x):
    """Normalize input vector x to the range [0, 1]."""
    x_min, x_max = np.min(x), np.max(x)
    return (x - x_min) / (x_max - x_min + 1e-8)

def encode_input(circuit, x_normalized):
    """Encode the normalized input x into the quantum circuit using Ry rotations."""
    for i, value in enumerate(x_normalized):
        theta = 2 * np.arcsin(value)
        circuit.ry(theta, i)
    return circuit

def entangle_qubits(circuit, num_qubits):
    """Apply linear CNOT entanglement among qubits."""
    for i in range(num_qubits - 1):
        circuit.cx(i, i + 1)
    return circuit

def measure_expectation(circuit, num_qubits, shots=1024):
    """Measure the quantum circuit and estimate probabilities."""
    circuit.measure_all()
    simulator = Aer.get_backend('aer_simulator')
    transpiled = transpile(circuit, simulator)
    job = simulator.run(assemble(transpiled, shots=shots))
    result = job.result()
    counts = result.get_counts()

    probabilities = np.zeros(num_qubits)
    for bitstring, count in counts.items():
        for i, bit in enumerate(reversed(bitstring)):
            if bit == '1':
                probabilities[i] += count
    return probabilities / shots

def reconstruct_input(probabilities):
    """Reconstruct the input vector from measured probabilities."""
    return np.arcsin(np.sqrt(probabilities))

def run_qcaa_non_optimized(x, shots=1024):
    """
    Execute the non-optimized QCAA algorithm.

    Parameters:
    - x: Input vector of shape (d,)
    - shots: Number of measurement shots

    Returns:
    - reconstructed_x: Reconstructed input vector
    - circuit: Final quantum circuit
    """
    x_normalized = normalize_input(np.array(x))
    num_qubits = len(x_normalized)

    circuit = QuantumCircuit(num_qubits)
    circuit = encode_input(circuit, x_normalized)
    circuit = entangle_qubits(circuit, num_qubits)
    probabilities = measure_expectation(circuit, num_qubits, shots=shots)
    reconstructed_x = reconstruct_input(probabilities)

    return reconstructed_x, circuit
