
# QCAA (Quantum-Classical Adaptive Autoencoder) - Non-Optimized Version

This repository contains the full implementation of the QCAA algorithm (Non-Optimized variant), which is described in the paper _"Quantum-Classical Adaptive Autoencoding of Time-Series Signals for Secure Biometric Authentication"_.

## Description
The QCAA model simulates the quantum encoding and reconstruction of a 16-dimensional biometric time-series vector using Qiskit. The simulation mimics execution on IBMQ backends such as `ibmq_manila` and `ibmq_jakarta`, which are now retired. Therefore, this code uses the `Aer` simulator to reproduce the expected behavior faithfully.

## Justification
Due to the retirement of IBMQ devices, the circuits in this implementation are executed on Qiskit’s high-fidelity `qasm_simulator`. This preserves the exact theoretical structure and measurement mechanism of earlier hardware runs. The reconstruction is derived from quantum measurement statistics using Ry-angle encoding and CNOT entanglement.

## How to Run

```bash
pip install qiskit numpy matplotlib
python qcaa/qcaa_non_optimized.py
```

## Input
The input should be a 16-dimensional normalized real vector (values between 0 and 1).

## Output
- Quantum circuit diagram
- Estimated reconstruction values
- Probability measurement per qubit
