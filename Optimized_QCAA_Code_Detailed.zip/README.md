
# Optimized QCAA Algorithm

This repository contains a simulation of the Optimized Quantum-Classical Adaptive Autoencoder (QCAA) algorithm, as described in the research article. The simulation replicates D-Wave quantum annealing using synthetic QUBO sampling.

## Files
- `optimized_qcaa.py`: Main implementation of the Optimized QCAA algorithm.
- `README.md`: Instructions and description.

## How to Run

1. Install Qiskit:
```bash
pip install qiskit
```

2. Run the main algorithm script:
```bash
python optimized_qcaa.py
```

## Description

- Quantum encoding is simulated via `Qiskit`.
- Optimization mask selection is mimicked using random sampling (representing D-Wave sampling).
- The algorithm performs multiple trials and returns the best reconstruction.

## Note

Due to hardware constraints and reproducibility, quantum annealing is simulated, and D-Wave QUBO sampling is mimicked using stochastic logic.
